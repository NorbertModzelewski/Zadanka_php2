<?php
$imiona = array("Martyna","Magda","Norbert","Filip","Kacper","Mateusz","Dawid","Liza","Oliwier","Seweryn","Oskar","Kinga","Adam","Dawid","Rafał");
for($i=0;$i<15;$i++){
echo $imiona[$i]."<br>";
}



?>