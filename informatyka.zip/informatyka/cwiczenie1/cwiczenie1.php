<?php
$a=5;
$b= "XD";
$suma = 0;
echo $a;
echo $b;
for($i=0; $i<100;$i++){
    $los = rand(1, 100);
    if($los%2==0){
        $suma= $suma + $los;
    }
   echo $suma;
}
?>