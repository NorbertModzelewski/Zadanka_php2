<?php

    $a = 0

    while($a==1000){
        echo(rand(1,1000));
    }

?>