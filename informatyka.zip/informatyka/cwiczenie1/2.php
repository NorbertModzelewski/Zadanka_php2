<?php

for ($a=0; $a<1000; $a++) {
    $b = rand(1,1000);
    echo $b."<br>";
}

?>